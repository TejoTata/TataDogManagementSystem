/**
 * 
 */
package com.TataClasses.DMS.repository;

import org.springframework.data.repository.CrudRepository;

import com.TataClasses.DMS.Models.Trainer;

/**
 * @author Tejo Lakshmi Tata
 *
 */
public interface TrainerRepository extends CrudRepository<Trainer, Integer> {
	

}
